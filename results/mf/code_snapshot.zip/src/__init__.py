"""Shared recommendation project code."""
